package week_01;

import javax.swing.JOptionPane;

/** Giao diện minh họa mật mã Playfair. */
public class frm_Playfair extends javax.swing.JFrame {
    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(frm_Playfair.class.getName());

    public frm_Playfair() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_title = new javax.swing.JLabel();
        lbl_plaintext = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_plaintext = new javax.swing.JTextArea();
        lbl_key = new javax.swing.JLabel();
        txt_key = new javax.swing.JTextField();
        lbl_hint = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txt_matrix = new javax.swing.JTextArea();
        btn_matrix = new javax.swing.JButton();
        btn_encrypt = new javax.swing.JButton();
        btn_decrypt = new javax.swing.JButton();
        btn_open = new javax.swing.JButton();
        btn_save = new javax.swing.JButton();
        lbl_ciphertext = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txt_ciphertext = new javax.swing.JTextArea();
        lbl_status = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Playfair Cipher");
        setMinimumSize(new java.awt.Dimension(820, 570));

        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbl_title.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lbl_title.setText("MẬT MÃ PLAYFAIR");

        lbl_plaintext.setText("Plaintext:");

        txt_plaintext.setColumns(20);
        txt_plaintext.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setRows(3);
        txt_plaintext.setWrapStyleWord(true);
        jScrollPane1.setViewportView(txt_plaintext);

        lbl_key.setText("Key:");

        txt_key.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_key.setText("KEYWORD");

        lbl_hint.setText("Chỉ gồm chữ A-Z, ví dụ KEYWORD");

        jLabel6.setText("Key Matrix:");

        txt_matrix.setEditable(false);
        txt_matrix.setColumns(9);
        txt_matrix.setFont(new java.awt.Font("Monospaced", 1, 14));
        txt_matrix.setRows(5);
        jScrollPane3.setViewportView(txt_matrix);

        btn_matrix.setText("Generate Key Matrix");
        btn_matrix.addActionListener(this::btn_matrixActionPerformed);

        btn_encrypt.setText("Encrypt");
        btn_encrypt.addActionListener(this::btn_encryptActionPerformed);

        btn_decrypt.setText("Decrypt");
        btn_decrypt.addActionListener(this::btn_decryptActionPerformed);

        btn_open.setText("Open Ciphertext File");
        btn_open.addActionListener(this::btn_openActionPerformed);

        btn_save.setText("Save Ciphertext File");
        btn_save.addActionListener(this::btn_saveActionPerformed);

        lbl_ciphertext.setText("Ciphertext:");

        txt_ciphertext.setColumns(20);
        txt_ciphertext.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setRows(3);
        txt_ciphertext.setWrapStyleWord(true);
        jScrollPane2.setViewportView(txt_ciphertext);

        lbl_status.setForeground(new java.awt.Color(30, 102, 65));
        lbl_status.setText("Sẵn sàng.");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_title)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbl_plaintext, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_key, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_ciphertext, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 650, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txt_key, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(14, 14, 14)
                                .addComponent(lbl_hint))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_matrix, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane2)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btn_encrypt, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(14, 14, 14)
                                .addComponent(btn_decrypt, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(14, 14, 14)
                                .addComponent(btn_open, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(14, 14, 14)
                                .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lbl_status))))
                .addGap(22, 22, 22))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lbl_title)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_plaintext)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_key)
                    .addComponent(txt_key, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_hint))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_matrix, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_ciphertext)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_encrypt, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_decrypt, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_open, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(lbl_status)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_matrixActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_matrixActionPerformed
        try {
            String key = txt_key.getText().trim();
            txt_matrix.setText(PlayfairCipher.getKeyMatrix(key));
            lbl_status.setText("Đã tạo ma trận khóa 5x5 (I và J dùng chung ô).");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Khóa không hợp lệ", JOptionPane.ERROR_MESSAGE);
            txt_key.requestFocusInWindow();
            txt_key.selectAll();
        }
    }//GEN-LAST:event_btn_matrixActionPerformed

    private void btn_encryptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_encryptActionPerformed
         String plaintext = txt_plaintext.getText(); 
 if (plaintext.isEmpty()) { 
 JOptionPane.showMessageDialog(this, "Hãy nhập Plaintext trước khi mã hóa."); 
 return; 
 } 
 try { 
 String key = txt_key.getText().trim(); 
 txt_ciphertext.setText(PlayfairCipher.encrypt(plaintext, key)); 
 lbl_status.setText("Đã mã hóa Playfair (bỏ dấu cách, J -> I, chèn X)."); 
 } catch (IllegalArgumentException ex) { 
 JOptionPane.showMessageDialog(this, ex.getMessage(), 
 "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE); 
 }


    }//GEN-LAST:event_btn_encryptActionPerformed

    private void btn_decryptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_decryptActionPerformed
         String ciphertext = txt_ciphertext.getText(); 
 if (ciphertext.isEmpty()) { 
 JOptionPane.showMessageDialog(this, "Hãy nhập Ciphertext trước khi giải mã."); 
 return; 
 } 
 try { 
 String key = txt_key.getText().trim(); 
 txt_plaintext.setText(PlayfairCipher.decrypt(ciphertext, key)); 
 lbl_status.setText("Đã giải mã Playfair (còn ký tự đệm X)."); 
 } catch (IllegalArgumentException ex) { 
 JOptionPane.showMessageDialog(this, ex.getMessage(), 
 "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE); 
 }

    }//GEN-LAST:event_btn_decryptActionPerformed

    private void btn_openActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_openActionPerformed
        String path = FileTextIO.openText(this, txt_ciphertext);
        if (path != null) lbl_status.setText("Đã mở tệp: " + path);
    }//GEN-LAST:event_btn_openActionPerformed

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
         String path = FileTextIO.saveText(this, txt_ciphertext, "playfair_ciphertext.txt"); 
 if (path != null) { 
 lbl_status.setText("Đã lưu tệp: " + path); 
 }

    }//GEN-LAST:event_btn_saveActionPerformed

    private Integer readKey() {
        try {
            return Integer.valueOf(txt_key.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Khóa Caesar phải là số nguyên, ví dụ 3.",
                    "Khóa không hợp lệ", JOptionPane.ERROR_MESSAGE);
            txt_key.requestFocusInWindow();
            txt_key.selectAll();
            return null;
        }
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(() -> new frm_Playfair().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_decrypt;
    private javax.swing.JButton btn_encrypt;
    private javax.swing.JButton btn_matrix;
    private javax.swing.JButton btn_open;
    private javax.swing.JButton btn_save;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel lbl_ciphertext;
    private javax.swing.JLabel lbl_hint;
    private javax.swing.JLabel lbl_key;
    private javax.swing.JLabel lbl_plaintext;
    private javax.swing.JLabel lbl_status;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JTextArea txt_ciphertext;
    private javax.swing.JTextField txt_key;
    private javax.swing.JTextArea txt_matrix;
    private javax.swing.JTextArea txt_plaintext;
    // End of variables declaration//GEN-END:variables
}
