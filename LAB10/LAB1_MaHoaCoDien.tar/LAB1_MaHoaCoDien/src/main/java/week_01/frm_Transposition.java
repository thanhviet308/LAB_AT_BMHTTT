package week_01;

import javax.swing.JOptionPane;

/** Giao diện minh họa mật mã Caesar. */
public class frm_Transposition extends javax.swing.JFrame {
    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(frm_Transposition.class.getName());

    public frm_Transposition() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        lbl_title = new javax.swing.JLabel();
        lbl_plaintext = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_plaintext = new javax.swing.JTextArea();
        lbl_key = new javax.swing.JLabel();
        txt_key = new javax.swing.JTextField();
        lbl_hint = new javax.swing.JLabel();
        btn_encrypt = new javax.swing.JButton();
        btn_decrypt = new javax.swing.JButton();
        btn_open = new javax.swing.JButton();
        btn_save = new javax.swing.JButton();
        lbl_ciphertext = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txt_ciphertext = new javax.swing.JTextArea();
        lbl_status = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Transposition Cipher");
        setMinimumSize(new java.awt.Dimension(650, 480));

        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18));
        lbl_title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_title.setText("MẬT MÃ HOÁN VỊ CỘT (TRANSPOSITION)");
        lbl_plaintext.setText("Plaintext:");

        txt_plaintext.setColumns(20);
        txt_plaintext.setFont(new java.awt.Font("Segoe UI", 0, 14));
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setRows(3);
        txt_plaintext.setWrapStyleWord(true);
        jScrollPane1.setViewportView(txt_plaintext);

        lbl_key.setText("Key:");
        txt_key.setFont(new java.awt.Font("Segoe UI", 0, 14));
        txt_key.setText("2,3,1");
        lbl_hint.setText("Thứ tự đọc cột, cách nhau dấu phẩy, ví dụ 2,3,1");

        btn_encrypt.setText("Encrypt");
        btn_encrypt.addActionListener(this::btn_encryptActionPerformed);
        btn_decrypt.setText("Decrypt");
        btn_decrypt.addActionListener(this::btn_decryptActionPerformed);
        btn_open.setText("Open Ciphertext File");
        btn_open.addActionListener(this::btn_openActionPerformed);
        btn_save.setText("Save Ciphertext File");
        btn_save.addActionListener(this::btn_saveActionPerformed);

        lbl_ciphertext.setText("Ciphertext:");
        txt_ciphertext.setColumns(20);
        txt_ciphertext.setFont(new java.awt.Font("Segoe UI", 0, 14));
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setRows(3);
        txt_ciphertext.setWrapStyleWord(true);
        jScrollPane2.setViewportView(txt_ciphertext);

        lbl_status.setForeground(new java.awt.Color(30, 102, 65));
        lbl_status.setText("Sẵn sàng.");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_title, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbl_plaintext)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbl_key)
                        .addGap(18, 18, 18)
                        .addComponent(txt_key, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14)
                        .addComponent(lbl_hint))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btn_encrypt, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addComponent(btn_decrypt, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addComponent(btn_open, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbl_ciphertext)
                    .addComponent(jScrollPane2)
                    .addComponent(lbl_status))
                .addGap(32, 32, 32))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lbl_title)
                .addGap(22, 22, 22)
                .addComponent(lbl_plaintext)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_key)
                    .addComponent(txt_key, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_hint))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_encrypt, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_decrypt, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_open, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(lbl_ciphertext)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(lbl_status)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_encryptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_encryptActionPerformed
        String plaintext = txt_plaintext.getText(); 
 if (plaintext.isEmpty()) { 
 JOptionPane.showMessageDialog(this, "Hãy nhập Plaintext trước khi mã hóa."); 
 return; 
 } 
 try { 
 int[] key = TranspositionCipher.parseKey(txt_key.getText()); 
 txt_ciphertext.setText(TranspositionCipher.encrypt(plaintext, key)); 
 lbl_status.setText("Đã mã hóa với " + key.length + " cột."); 
 } catch (IllegalArgumentException ex) { 
 JOptionPane.showMessageDialog(this, ex.getMessage(), 
 "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE); 
 }

    }//GEN-LAST:event_btn_encryptActionPerformed

    private void btn_decryptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_decryptActionPerformed
         String ciphertext = txt_ciphertext.getText(); 
 if (ciphertext.isEmpty()) { 
 JOptionPane.showMessageDialog(this, "Hãy nhập Ciphertext trước khi giải mã."); 
 return; 
 } 
 try { 
 int[] key = TranspositionCipher.parseKey(txt_key.getText()); 
 txt_plaintext.setText(TranspositionCipher.decrypt(ciphertext, key)); 
 lbl_status.setText("Đã giải mã với " + key.length + " cột."); 
 } catch (IllegalArgumentException ex) { 
 JOptionPane.showMessageDialog(this, ex.getMessage(), 
 "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE); 
 }

    }//GEN-LAST:event_btn_decryptActionPerformed

    private void btn_openActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_openActionPerformed
        String path = FileTextIO.openText(this, txt_ciphertext);
        if (path != null) lbl_status.setText("Đã mở tệp: " + path);
    }//GEN-LAST:event_btn_openActionPerformed

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
         String path = FileTextIO.saveText(this, txt_ciphertext, "transposition_ciphertext.txt"); 
 if (path != null) { 
 lbl_status.setText("Đã lưu tệp: " + path); 
 }

    }//GEN-LAST:event_btn_saveActionPerformed

    private Integer readKey() {
        try {
            return Integer.valueOf(txt_key.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Khóa Caesar phải là số nguyên, ví dụ 3.",
                    "Khóa không hợp lệ", JOptionPane.ERROR_MESSAGE);
            txt_key.requestFocusInWindow();
            txt_key.selectAll();
            return null;
        }
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(() -> new frm_Transposition().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_decrypt;
    private javax.swing.JButton btn_encrypt;
    private javax.swing.JButton btn_open;
    private javax.swing.JButton btn_save;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbl_ciphertext;
    private javax.swing.JLabel lbl_hint;
    private javax.swing.JLabel lbl_key;
    private javax.swing.JLabel lbl_plaintext;
    private javax.swing.JLabel lbl_status;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JTextArea txt_ciphertext;
    private javax.swing.JTextField txt_key;
    private javax.swing.JTextArea txt_plaintext;
    // End of variables declaration//GEN-END:variables
}


